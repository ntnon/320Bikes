bikeOntology.obda contains the mappings.

bikeOntology-mapping.ttl contains an export of the mappings in turtle syntax.

bikeOntology.owx contains the ontology saved in OWL/XML syntax.

bikeOntology.rdf contains the ontology saved in RDF syntax.

bikeOntology.q contains saved SPARQL queries used for testing.

bikeOntology.properties contains the connection parametres to the database server.

public.sql contains a dumb of the SQL schema.

rows.sql contains a dump of the rows in the SQL database.
